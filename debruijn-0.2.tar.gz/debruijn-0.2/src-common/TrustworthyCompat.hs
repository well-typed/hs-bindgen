{-# LANGUAGE Trustworthy #-}
module TrustworthyCompat (
    coerce,
) where

import Data.Coerce (coerce)
